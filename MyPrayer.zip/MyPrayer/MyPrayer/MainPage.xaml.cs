﻿using Microsoft.Maui.Controls;
using Microsoft.Extensions.DependencyInjection;

namespace MyPrayer
{
    public partial class MainPage : ContentPage
    {
        private readonly IServiceProvider _serviceProvider;

        public MainPage(IServiceProvider serviceProvider)
        {
            InitializeComponent();
            _serviceProvider = serviceProvider;
        }

        private async void OnGebetszeitplanClicked(object sender, EventArgs e)
        {
            // Verwende den DI-Container, um die Seite zu erstellen
            await Navigation.PushAsync(new GebetszeitplanPage(new FirebaseService()));  // Testweise ohne DI

        }

        private async void OnPrayersClicked(object sender, EventArgs e)
        {
            await Navigation.PushAsync(new PrayersPage());
        }

        private async void OnMeineGebeteClicked(object sender, EventArgs e)
        {
            await Navigation.PushAsync(new MyPrayersPage());
        }

        private async void OnBackButtonClicked(object sender, EventArgs e)
        {
            if (Navigation.NavigationStack.Count > 1)
            {
                await Navigation.PopAsync();
            }
        }
    }
}
