using System;
using Microsoft.Maui.Controls;

namespace MyPrayer
{
    public partial class AddPrayerToPrayersPage : ContentPage
    {
        // Event, das ausgel�st wird, wenn ein Gebet hinzugef�gt wird
        public event EventHandler<Prayer> PrayerAdded;

        private readonly FirebaseService _firebaseService;

        public AddPrayerToPrayersPage()
        {
            InitializeComponent();
            _firebaseService = new FirebaseService(); // FirebaseService instanziieren
        }

        private async void OnAddPrayerButtonClicked(object sender, EventArgs e)
        {
            string prayerName = PrayerNameEntry.Text;
            string prayerContent = PrayerContentEntry.Text;

           

            if (string.IsNullOrEmpty(prayerName) || string.IsNullOrEmpty(prayerContent))
            {
                await DisplayAlert("Fehler", "Bitte geben Sie sowohl den Namen als auch den Inhalt des Gebets ein.", "OK");
                return;
            }

            var prayer = new Prayer
            {
                Name = prayerName,
                Content = prayerContent,
               
            };

            try
            {
                // Gebet zur Firebase-Datenbank hinzuf�gen
                await _firebaseService.AddPrayerAsync(prayer);

                // Event ausl�sen, um das neue Gebet zur Liste hinzuzuf�gen
                PrayerAdded?.Invoke(this, prayer);  // Prayer zur�ckgeben

               

                await DisplayAlert("Erfolg", "Das Gebet wurde erfolgreich hinzugef�gt.", "OK");

                // Zur�ck zur vorherigen Seite navigieren
                await Navigation.PopAsync();
            }
            catch (Exception ex)
            {
                await DisplayAlert("Fehler", "Gebet konnte nicht hinzugef�gt werden: " + ex.Message, "OK");
            }
        }

       
    
    }
}
