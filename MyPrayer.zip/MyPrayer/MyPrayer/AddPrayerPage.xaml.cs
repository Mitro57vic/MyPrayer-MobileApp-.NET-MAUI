using Plugin.LocalNotification;
using System;
using System.Collections.ObjectModel;
using System.Threading.Tasks;
using Microsoft.Maui.Controls;

namespace MyPrayer
{
    public partial class AddPrayerPage : ContentPage
    {
        private readonly ObservableCollection<Prayer> _prayers;
        private readonly FirebaseService _firebaseService;

        public AddPrayerPage(ObservableCollection<Prayer> prayers, FirebaseService firebaseService)
        {
            InitializeComponent();
            _prayers = prayers;
            _firebaseService = firebaseService;
        }

        private async void OnAddPrayerButtonClicked(object sender, EventArgs e)
        {
            // Get user input
            string prayerName = PrayerNameEntry.Text;
            string prayerTime = PrayerTimeEntry.Text;  // Input in HH:mm format expected
            string prayerContent = PrayerContentEntry.Text;

            // Validate inputs: name and time cannot be empty
            if (string.IsNullOrWhiteSpace(prayerName) || string.IsNullOrWhiteSpace(prayerTime))
            {
                await DisplayAlert("Fehler", "Bitte geben Sie den Namen und die Uhrzeit des Gebets ein.", "OK");
                return;
            }

            if (TimeSpan.TryParse(prayerTime, out TimeSpan parsedTime))
            {
                var newPrayer = new Prayer
                {
                    Name = prayerName,
                    NotificationTime = parsedTime,
                    Content = prayerContent
                };

                try
                {
                    
                    await _firebaseService.AddPrayerAsync(newPrayer);

                   
                    _prayers.Add(newPrayer);

                    
                    ScheduleNotification(prayerName, parsedTime);

                    
                    await Navigation.PopAsync();
                }
                catch (Exception ex)
                {
                    await DisplayAlert("Fehler", "Das Gebet konnte nicht hinzugef�gt werden: " + ex.Message, "OK");
                }
            }
            else
            {
                await DisplayAlert("Fehler", "Bitte geben Sie die Uhrzeit im Format HH:mm ein.", "OK");
            }
        }

        
        private void ScheduleNotification(string prayerName, TimeSpan time)
        {
            var notificationTime = DateTime.Today.Add(time);

            
            if (notificationTime < DateTime.Now)
            {
                
                notificationTime = notificationTime.AddDays(1);
            }

            var notification = new NotificationRequest
            {
                NotificationId = new Random().Next(),
                Title = "Gebets-Erinnerung",
                Description = $"Es ist Zeit f�r das Gebet: {prayerName}",
                Schedule =
        {
            NotifyTime = notificationTime 
        }
            };

            // Benachrichtigung anzeigen
           // LocalNotificationCenter.Current.Show(notification);
        }
    }
}
