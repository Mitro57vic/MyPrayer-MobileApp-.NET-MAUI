﻿using Microsoft.Extensions.DependencyInjection;

namespace MyPrayer
{
    public partial class App : Application
    {
        public App()
        {
            InitializeComponent();

            var serviceCollection = new ServiceCollection();
            ConfigureServices(serviceCollection);

            var serviceProvider = serviceCollection.BuildServiceProvider();

            MainPage = new NavigationPage(serviceProvider.GetService<MainPage>());
        }

        private void ConfigureServices(IServiceCollection services)
        {
            // Registriere hier deine Seiten und andere Services
            services.AddTransient<MainPage>();
            services.AddTransient<GebetszeitplanPage>();
            services.AddTransient<PrayersPage>();
            services.AddTransient<MyPrayersPage>();
        }
    }
}