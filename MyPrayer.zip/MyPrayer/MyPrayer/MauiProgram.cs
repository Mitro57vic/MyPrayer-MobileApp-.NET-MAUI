﻿using Microsoft.Extensions.Logging;
using System.IO;

namespace MyPrayer
{
    public static class MauiProgram
    {
        public static MauiApp CreateMauiApp()
        {
            var builder = MauiApp.CreateBuilder();
            builder
                .UseMauiApp<App>()
                .ConfigureFonts(fonts =>
                {
                    fonts.AddFont("OpenSans-Regular.ttf", "OpenSansRegular");
                    fonts.AddFont("OpenSans-Semibold.ttf", "OpenSansSemibold");
                });

            // Initialisiere die SQLite-Datenbank
            string dbPath = Path.Combine(FileSystem.AppDataDirectory, "prayers.db3");

            builder.Services.AddSingleton<FirebaseService>();  
            builder.Services.AddTransient<GebetszeitplanPage>(); 
            builder.Services.AddSingleton<MainPage>();

#if DEBUG
            builder.Logging.AddDebug();
#endif

            return builder.Build();
        }
    }
}
