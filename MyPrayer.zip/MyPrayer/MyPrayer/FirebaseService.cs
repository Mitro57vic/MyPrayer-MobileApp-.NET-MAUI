﻿using Firebase.Database;
using Firebase.Database.Query;
using System.Linq;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace MyPrayer
{
    public class FirebaseService
    {
        private readonly FirebaseClient firebaseClient;

        public FirebaseService()
        {
           
            firebaseClient = new FirebaseClient("https://myprayerapp-25f4f-default-rtdb.firebaseio.com/");
        }

        // Add a prayer to Firebase and store its unique Firebase ID
        public async Task AddPrayerAsync(Prayer prayer)
        {
            var result = await firebaseClient
                .Child("Prayers")
                .PostAsync(prayer);

           
            prayer.Id = result.Key;
        }

       
        public async Task<List<Prayer>> GetPrayersAsync()
        {
            var prayers = (await firebaseClient
                .Child("Prayers")
                .OnceAsync<Prayer>())
                .Select(item => new Prayer
                {
                    Id = item.Key,  
                    Name = item.Object.Name,
                    Content = item.Object.Content,
                    NotificationTime = item.Object.NotificationTime
                })
                .ToList();

            return prayers;
        }

        
        public async Task DeletePrayerAsync(Prayer prayer)
        {
            await firebaseClient
                .Child("Prayers")
                .Child(prayer.Id)  
                .DeleteAsync();
        }
    }
}
