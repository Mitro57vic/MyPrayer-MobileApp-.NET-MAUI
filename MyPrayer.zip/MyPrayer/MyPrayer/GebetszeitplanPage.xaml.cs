using System;
using System.Collections.ObjectModel;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.Maui.Controls;

namespace MyPrayer
{
    public partial class GebetszeitplanPage : ContentPage
    {
        private readonly FirebaseService _firebaseService;
        public ObservableCollection<Prayer> Prayers { get; set; }

        public GebetszeitplanPage(FirebaseService firebaseService)
        {
            InitializeComponent();

            _firebaseService = firebaseService;

            Prayers = new ObservableCollection<Prayer>();

            // Gebete aus Firebase laden
            LoadPrayers();

            PrayerListView.ItemsSource = Prayers;

            // Event-Handler f�r den Accelerometer
            Accelerometer.ReadingChanged += OnAccelerometerReadingChanged;
        }

        protected override void OnAppearing()
        {
            base.OnAppearing();
            Accelerometer.Start(SensorSpeed.UI); // Beschleunigungssensor starten
        }

        protected override void OnDisappearing()
        {
            base.OnDisappearing();
            Accelerometer.Stop(); // Beschleunigungssensor stoppen
        }

        private async void LoadPrayers()
        {
            try
            {
                var prayersFromFirebase = await _firebaseService.GetPrayersAsync();
                Prayers = new ObservableCollection<Prayer>(prayersFromFirebase);
                PrayerListView.ItemsSource = Prayers;  // Liste in der UI aktualisieren
            }
            catch (Exception ex)
            {
                await DisplayAlert("Fehler", "Gebete konnten nicht geladen werden: " + ex.Message, "OK");
            }
        }

        private async void OnAddPrayerClicked(object sender, EventArgs e)
        {
            var addPrayerPage = new AddPrayerPage(Prayers, _firebaseService);
            await Navigation.PushAsync(addPrayerPage);
        }

        private async void OnDeletePrayerClicked(object sender, EventArgs e)
        {
            var button = (Button)sender;
            var stackLayout = (StackLayout)button.Parent;
            var label = (Label)stackLayout.Children.FirstOrDefault(child => child is Label);
            var prayer = (Prayer)label?.BindingContext;

            if (prayer != null)
            {
                bool isConfirmed = await DisplayAlert("Best�tigung", "M�chten Sie dieses Gebet wirklich l�schen?", "Ja", "Nein");
                if (isConfirmed)
                {
                    try
                    {
                        await _firebaseService.DeletePrayerAsync(prayer);
                        Prayers.Remove(prayer);
                    }
                    catch (Exception ex)
                    {
                        await DisplayAlert("Fehler", "Das Gebet konnte nicht gel�scht werden: " + ex.Message, "OK");
                    }
                }
            }
        }

        private async void OnBackButtonClicked(object sender, EventArgs e)
        {
            if (Navigation.NavigationStack.Count > 1)
            {
                await Navigation.PopAsync();
            }
        }

        private void OnAccelerometerReadingChanged(object sender, AccelerometerChangedEventArgs e)
        {
            var reading = e.Reading;

            // �berpr�fe die Beschleunigungswerte f�r die Sch�ttelbewegung
            if (Math.Abs(reading.Acceleration.X) > 3.0 ||
                Math.Abs(reading.Acceleration.Y) > 3.0 ||
                Math.Abs(reading.Acceleration.Z) > 3.0)
            {
                // Sch�ttelbewegung erkannt, f�hre die gew�nschte Aktion aus
                DisplayAlert("Sch�ttelgesten erkannt", "Benachrichtigungen gestoppt oder snoozen", "OK");
            }
        }
    }

    public class Prayer
    {
        public string Id { get; set; }
        public string Name { get; set; }
        public TimeSpan NotificationTime { get; set; }
        public string Content { get; set; }
    }
}
