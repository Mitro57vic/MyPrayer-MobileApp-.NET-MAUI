namespace MyPrayer;

public partial class JesusPrayer : ContentPage
{
    public JesusPrayer()
    {
        InitializeComponent();
    }


    private async void OnBackButtonClicked(object sender, EventArgs e)
    {
        if (Navigation.NavigationStack.Count > 1)
        {
            await Navigation.PopAsync();
        }
        else
        {

        }

    }
}